import csv
import os
from collections import deque

import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray


class WheelPlotter(Node):
    def __init__(self):
        super().__init__('wheel_plotter')

        self.declare_parameter('csv_path', os.path.expanduser('~/wheel_telem_log.csv'))
        self.csv_path = self.get_parameter('csv_path').value

        self.sub = self.create_subscription(
            Float32MultiArray,
            '/wheel_telem',
            self.cb,
            10
        )

        self.maxlen = 400

        self.t = deque(maxlen=self.maxlen)
        self.wl_ref = deque(maxlen=self.maxlen)
        self.wr_ref = deque(maxlen=self.maxlen)
        self.wl_meas = deque(maxlen=self.maxlen)
        self.wr_meas = deque(maxlen=self.maxlen)
        self.eL = deque(maxlen=self.maxlen)
        self.eR = deque(maxlen=self.maxlen)
        self.uL = deque(maxlen=self.maxlen)
        self.uR = deque(maxlen=self.maxlen)

        self.t0 = None

        self.csv_file = open(self.csv_path, 'w', newline='')
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow([
            't_s',
            'v_cmd', 'w_cmd',
            'wl_ref', 'wr_ref',
            'wl_meas', 'wr_meas',
            'eL', 'eR',
            'uL', 'uR'
        ])
        self.csv_file.flush()

        self.get_logger().info(f'Guardando CSV en: {self.csv_path}')

        self.fig, self.axs = plt.subplots(4, 1, figsize=(10, 12))

        self.anim = FuncAnimation(self.fig, self.update_plot, interval=100, cache_frame_data=False)

    def cb(self, msg: Float32MultiArray):
        if len(msg.data) < 11:
            return

        t_ms = float(msg.data[0])
        v_cmd = float(msg.data[1])
        w_cmd = float(msg.data[2])
        wl_ref = float(msg.data[3])
        wr_ref = float(msg.data[4])
        wl_meas = float(msg.data[5])
        wr_meas = float(msg.data[6])
        eL = float(msg.data[7])
        eR = float(msg.data[8])
        uL = float(msg.data[9])
        uR = float(msg.data[10])

        t_s_abs = t_ms / 1000.0
        if self.t0 is None:
            self.t0 = t_s_abs
        t_s = t_s_abs - self.t0

        self.t.append(t_s)
        self.wl_ref.append(wl_ref)
        self.wr_ref.append(wr_ref)
        self.wl_meas.append(wl_meas)
        self.wr_meas.append(wr_meas)
        self.eL.append(eL)
        self.eR.append(eR)
        self.uL.append(uL)
        self.uR.append(uR)

        self.csv_writer.writerow([
            t_s,
            v_cmd, w_cmd,
            wl_ref, wr_ref,
            wl_meas, wr_meas,
            eL, eR,
            uL, uR
        ])
        self.csv_file.flush()

    def update_plot(self, _frame):
        for ax in self.axs:
            ax.clear()

        if len(self.t) == 0:
            return

        # Gráfica 1: rueda izquierda
        self.axs[0].plot(self.t, self.wl_ref, label='wl_ref')
        self.axs[0].plot(self.t, self.wl_meas, label='wl_meas')
        self.axs[0].set_title('Motor izquierdo')
        self.axs[0].set_ylabel('rad/s')
        self.axs[0].grid(True)
        self.axs[0].legend()

        # Gráfica 2: rueda derecha
        self.axs[1].plot(self.t, self.wr_ref, label='wr_ref')
        self.axs[1].plot(self.t, self.wr_meas, label='wr_meas')
        self.axs[1].set_title('Motor derecho')
        self.axs[1].set_ylabel('rad/s')
        self.axs[1].grid(True)
        self.axs[1].legend()

        # Gráfica 3: error
        self.axs[2].plot(self.t, self.eL, label='eL')
        self.axs[2].plot(self.t, self.eR, label='eR')
        self.axs[2].set_title('Error')
        self.axs[2].set_ylabel('rad/s')
        self.axs[2].grid(True)
        self.axs[2].legend()

        # Gráfica 4: acción de control
        self.axs[3].plot(self.t, self.uL, label='uL')
        self.axs[3].plot(self.t, self.uR, label='uR')
        self.axs[3].set_title('Acción de control')
        self.axs[3].set_ylabel('PWM/PID')
        self.axs[3].set_xlabel('Tiempo [s]')
        self.axs[3].grid(True)
        self.axs[3].legend()

        self.fig.tight_layout()

    def spin_with_plot(self):
        plt.show(block=False)
        while rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.05)
            plt.pause(0.01)

    def close(self):
        try:
            self.csv_file.close()
        except Exception:
            pass


def main():
    rclpy.init()
    node = WheelPlotter()
    try:
        node.spin_with_plot()
    finally:
        node.close()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
