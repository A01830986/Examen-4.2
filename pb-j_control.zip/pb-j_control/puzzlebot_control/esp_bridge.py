import serial
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray


class EspBridge(Node):
    def __init__(self):
        super().__init__('esp_bridge')

        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baud', 115200)

        port = self.get_parameter('port').value
        baud = self.get_parameter('baud').value

        self.ser = serial.Serial(port, baud, timeout=0.05)

        self.pub_telem = self.create_publisher(Float32MultiArray, '/wheel_telem', 10)
        self.sub_ref = self.create_subscription(
            Float32MultiArray,
            '/wheel_ref',
            self.ref_callback,
            10
        )

        self.timer = self.create_timer(0.02, self.read_serial)

        self.get_logger().info(f'Conectado a ESP8266 en {port} @ {baud}')

    def ref_callback(self, msg: Float32MultiArray):
        if len(msg.data) < 2:
            return

        wl = float(msg.data[0])
        wr = float(msg.data[1])

        line = f"WHEEL {wl:.4f} {wr:.4f}\n"
        self.ser.write(line.encode())

    def read_serial(self):
        try:
            line = self.ser.readline().decode(errors='ignore').strip()
            if not line.startswith('TEL'):
                return

            parts = line.split()
            if len(parts) != 12:
                return

            # Formato:
            # TEL t v_cmd w_cmd wl_ref wr_ref wl_meas wr_meas eL eR uL uR
            t_ms    = float(parts[1])
            v_cmd   = float(parts[2])
            w_cmd   = float(parts[3])
            wl_ref  = float(parts[4])
            wr_ref  = float(parts[5])
            wl_meas = float(parts[6])
            wr_meas = float(parts[7])
            eL      = float(parts[8])
            eR      = float(parts[9])
            uL      = float(parts[10])
            uR      = float(parts[11])

            msg = Float32MultiArray()
            msg.data = [
                t_ms,
                v_cmd, w_cmd,
                wl_ref, wr_ref,
                wl_meas, wr_meas,
                eL, eR,
                uL, uR
            ]
            self.pub_telem.publish(msg)

        except Exception as e:
            self.get_logger().warn(str(e))


def main():
    rclpy.init()
    node = EspBridge()
    try:
        rclpy.spin(node)
    finally:
        try:
            node.ser.write(b"STOP\n")
            node.ser.close()
        except Exception:
            pass
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
